/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vetor_exemplo_1;

/**
 *
 * @author f.oliveira
 */
//SOMA OS ELEMENTOS DE UM VETOR, DE TAMANHO 10, ARMAZENADOS
//ALEATERIAMENTE
public class VETOR_EXEMPLO_1 {

    public static void main(String[] args) {
// declaração da variável do tipo "vetor de inteiros longo(long)"
//com tamanho n = 10

 int n = 10;
 int vetor[] = new int [n];
 
 //entrada- alimenta o vetor com nros aleatório entre 0 e 9.
  for (int i=0; i<n; i++);
   vetor[i] = (int)(Math.random() * 10);
   
 //processsamento- percorre a soma os elementos do vetor.
  int sm = 0;
   


    }
}
